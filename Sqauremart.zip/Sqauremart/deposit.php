<?php include('header.php') ?>
<div class="admin-wrapper-page">
        <div class="admin-wrapper-col-4" id="sidenav">
<div class="admin-main">
    <div class="admin-sidebar">
        <?php include('sidebar.php') ?>
    </div>
</div>
</div>
    <div class="admin-wrapper-col-8">
        <div class="admin-topic">Transactions</div>
        <div class="admin-form-group-add">
            <h4>Deposit</h4>
            <div class="admin-col">
             <div class="actions">
                    <ul>
                        <li><button>copy</button></li>
                        <li><button id="downloadExcelButton">excel</button></li>
                        <li><button id="downloadButton">pdf</button></li>
                        <li><button id="printBtn" onclick="printDiv('printable-area')">print</button></li>
                    </ul>
                    </div>
              
                <div class="admin-search">
                    <label>Search:</label>
                    <input type="text" name="search"  id="searchInput" oninput="searchTable()" placeholder="Search for a value...">
                </div>
            </div>

            <div class="admin-deposit">
                <div class="admin-out"> 
                    
                        <h4>Deposit</h4>
                    <div class="table-responsive" id="printable-area">
                        <table id="tableToConvert" class="admin-out">
                            <tr>
                                <th>S/N</th>
                                <th>User id</th>
                                <th id="payment">Payment Method</th>
                                <th>Amount</th>
                                <th>Fee</th>
                                <th>Date</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                            <tr>
                                <td>1</td>
                                <td>Tman</td>
                                <td>Bank</td>
                                <td>200</td>
                                <td>0.00</td>
                                <td>19th Jan, 2023</td>
                                <td><button class="admin-error">cancel</button>
                                <td><button class="admin-det">Detail</button></td></td>
                            </tr>
                            <tr>
                                <td>2</td>
                                <td>Sman</td>
                                <td>Bank</td>
                                <td>200</td>
                                <td>0.00</td>
                                <td>19th Jan, 2023</td>
                                <td><button class="admin-success">success</button></td>
                                <td><button class="admin-det">Detail</button></td>
                            </tr>
                            <tr>
                                <td>3</td>
                                <td>$Baby</td>
                                <td>Bank</td>
                                <td>200</td>
                                <td>0.00</td>
                                <td>19th Jan, 2023</td>
                                <td><button class="admin-success">success</button></td>
                                <td><button class="admin-det">Detail</button></td>
                            </tr>
                            <tr>
                                <td>4</td>
                                <td>$baby</td>
                                <td>Bank</td>
                                <td>200</td>
                                <td>0.00</td>
                                <td>19th Jan, 2023</td>
                                <td><button class="admin-success">success</button></td>
                                <td><button class="admin-det">Detail</button></td>
                            </tr>
                            <tr>
                                <td>5</td>
                                <td>$baby</td>
                                <td>Bank</td>
                                <td>200</td>
                                <td>0.00</td>
                                <td>19th Jan, 2023</td>
                                <td><button class="admin-success">success</button></td>
                                <td><button class="admin-det">Detail</button></td>
                            </tr>
                            <tr>
                                <td>6</td>
                                <td>$baby</td>
                                <td>Bank</td>
                                <td>200</td>
                                <td>0.00</td>
                                <td>19th Jan, 2023</td>
                                <td><button class="admin-success">success</button></td>
                                <td><button class="admin-det">Detail</button></td>
                            </tr>
                            <tr>
                                <td>7</td>
                                <td>$baby</td>
                                <td>Bank</td>
                                <td>200</td>
                                <td>0.00</td>
                                <td>19th Jan, 2023</td>
                                <td><button class="admin-success">success</button></td>
                                <td><button class="admin-det">Detail</button></td>
                            </tr>
                            <tr>
                                <td>8</td>
                                <td>$baby</td>
                                <td>Bank</td>
                                <td>200</td>
                                <td>0.00</td>
                                <td>19th Jan, 2023</td>
                                <td><button class="admin-success">success</button></td>
                                <td><button class="admin-det">Detail</button></td>
                            </tr>
                            <tr>
                                <td>9</td>
                                <td>$baby</td>
                                <td>Bank</td>
                                <td>200</td>
                                <td>0.00</td>
                                <td>19th Jan, 2023</td>
                                <td><button class="admin-success">success</button></td>
                                <td><button class="admin-det">Detail</button></td>
                            </tr>
                            <tr>
                                <td>10</td>
                                <td>$baby</td>
                                <td>Bank</td>
                                <td>200</td>
                                <td>0.00</td>
                                <td>19th Jan, 2023</td>
                                <td><button class="admin-success">success</button></td>
                                <td><button class="admin-det">Detail</button></td>
                            </tr>
                        </table>
              
                        </div>
    </div>

               
            </div>
             <div class="admin-down">
                    <div class="rowsperpage">
                        <label for="rowsPerPage">Rows per Page:</label>
                        <select id="rowsPerPage">
                            <option value="5"  selected>5</option>
                            <option value="10">10</option>
                            <option value="15">15</option>
                        </select>

</div>
                    <div class="admin-btn">
                    <button class="admin-prev" id="prevBtn">prev</button>
                    <button class="admin-next" id="nextBtn">next</button>
                </div>
                </div>
        </div>
        
    </div>
</div>
<script>
        document.getElementById('downloadButton').addEventListener('click', function() {
            const element = document.getElementById('tableToConvert');
            
            html2pdf()
                .from(element)
                .save('table-to-pdf.pdf');
        });
    </script>
    <script>
        document.getElementById('downloadExcelButton').addEventListener('click', function() {
            const table = document.getElementById('tableToConvert');
            const wb = XLSX.utils.table_to_book(table);
            XLSX.writeFile(wb, 'table-export.xlsx');
        });
    </script>

<?php include('footer.php') ?>