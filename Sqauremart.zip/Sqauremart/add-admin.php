<?php include('header.php') ?>
<div class="admin-wrapper-page">
        <div class="admin-wrapper-col-4" id="sidenav">
<div class="admin-main">
    <div class="admin-sidebar">
        <?php include('sidebar.php') ?>
    </div>
</div>
</div>
   <div class="admin-wrapper-col-8">
        <div class="admin-topic">Add Admin</div>
            
    <div class="admin-form-group-add">
        <h4>Welcome back Admin</h4>
        
        <form action="">
            <div class="form-group">
            <div class="admin-form-input">
                <label for="">Add Admin</label>
                <div class="select2">
                 <select id="payment">
                        <option value="5"  selected disabled>select option</option>
                        <option value="10">Bank</option>
                        <option value="15">Transfer</option>
                    </select>
                    
            </div>
            </div>
            <div class="admin-form-input">
                <label for="">First Name</label>
                <input type="text">
            </div>
            <div class="admin-form-input">
                <label for="">Last Name</label>
                <input type="text">
            </div><div class="admin-form-input">
                <label for="">Email Address</label>
                <input type="email">
            </div><div class="admin-form-input">
                <label for="">Password</label>
                <input type="password">
            </div><div class="admin-form-input">
                <label for="">Confirm Password</label>
                <input type="password">
            </div>
</div>
<button class="submit">Save</button>
        </form>
    </div>



    
        </div>
    </div>
</div>

<?php include('footer.php') ?>