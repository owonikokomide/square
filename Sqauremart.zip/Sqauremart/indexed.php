<?php include('header.php') ?>
<div class="admin-wrapper-page">
        <div class="admin-wrapper-col-4">
<div class="admin-main">
    <div class="admin-sidebar">
        <?php include('sidebar.php') ?>
    </div>
</div>
</div>
    <div class="admin-full">
        <div class="admin-topic">Transactions</div>
        <div class="admin-real">
            <h3>Deposit</h3>
            <div class="admin-col">
                <table>
                    <tr>
                        <td><button>copy</button></td>
                        <td><button id="downloadExcelButton">excel</button></td>
                        <td><button id="downloadButton">pdf</button></td>
                        <td><button id="printBtn" >print</button></td>
                    </tr>
                </table>
                <div class="admin-search">
                    <label>Search</label>
                    <input type="text" name="search"  id="searchInput" oninput="searchTable()" placeholder="Search for a value...">
                </div>
            </div>

            <div class="admin-deposit">
                <table class="admin-out"> 
                    <tr >
                        <th>Depoist</th>
                    </tr>
                    <tr>
                        <table id="tableToConvert" class="admin-out">
                            <tr>
                                <th>S/N</th>
                                <th>User id</th>
                                <th>Payment Method</th>
                                <th>Amount</th>
                                <th>Fee</th>
                                <th>Date</th>
                                <th>Status</th>
                            </tr>
                            <tr>
                                <td>1</td>
                                <td>Tman</td>
                                <td>Bank</td>
                                <td>200</td>
                                <td>0.00</td>
                                <td>19th Jan, 2023</td>
                                <td><button class="admin-error">cancel</button></td>
                            </tr>
                            <tr>
                                <td>2</td>
                                <td>Sman</td>
                                <td>Bank</td>
                                <td>200</td>
                                <td>0.00</td>
                                <td>19th Jan, 2023</td>
                                <td><button>success</button></td>
                            </tr>
                            <tr>
                                <td>3</td>
                                <td>$Baby</td>
                                <td>Bank</td>
                                <td>200</td>
                                <td>0.00</td>
                                <td>19th Jan, 2023</td>
                                <td><button>success</button></td>
                            </tr>
                            <tr>
                                <td>4</td>
                                <td>$baby</td>
                                <td>Bank</td>
                                <td>200</td>
                                <td>0.00</td>
                                <td>19th Jan, 2023</td>
                                <td><button>success</button></td>
                            </tr>
                            <tr>
                                <td>5</td>
                                <td>$baby</td>
                                <td>Bank</td>
                                <td>200</td>
                                <td>0.00</td>
                                <td>19th Jan, 2023</td>
                                <td><button>success</button></td>
                            </tr>
                            <tr>
                                <td>6</td>
                                <td>$baby</td>
                                <td>Bank</td>
                                <td>200</td>
                                <td>0.00</td>
                                <td>19th Jan, 2023</td>
                                <td><button>success</button></td>
                            </tr>
                        </table>
                            <script>
        document.getElementById('downloadButton').addEventListener('click', function() {
            const element = document.getElementById('tableToConvert');
            
            html2pdf()
                .from(element)
                .save('table-to-pdf.pdf');
        });
    </script>
    <script>
        document.getElementById('downloadExcelButton').addEventListener('click', function() {
            const table = document.getElementById('tableToConvert');
            const wb = XLSX.utils.table_to_book(table);
            XLSX.writeFile(wb, 'table-export.xlsx');
        });
    </script>
                        </div>
                    </tr>
                </table>

                <div class="admin-down">
                    <p>
                        <label for="rowsPerPage">Rows per Page:</label>
                        <select id="rowsPerPage">
                            <option value="5"  selected>5</option>
                            <option value="10">10</option>
                            <option value="15">15</option>
                        </select>

                    </p>
                    <div class="admin-btn">
                    <button class="admin-prev" id="prevBtn">prev</button>
                    <button class="admin-next" id="nextBtn">next</button>
                </div>
                </div>
            </div>
        </div>
    </div>
  
<?php include('footer.php') ?>