 <div class="collapsible">
<nav>
    <div class="admin-side">
        <p>SquareMart</p>
        <p onclick="closenav()"><i class="fa-solid fa-times"></i></p>
    </div>
    <div class="admin">
        <i class="fa-solid fa-chart-pie"></i>
        <span id="list-items">Admin Dashboard</span>
        <i class="fa-solid fa-caret-down hidden" id="list-items"></i>
        <!-- <i class="fa-solid fa-caret-right show"></i> -->
       
    </div>
    <ul id="list">
        <li>
            <a href="" class="active"><i class="fas fa-regular fa-user"></i><span id="list-items">User Profiles</span></a>
        </li>
        <li>
            <a href=""><i class="fas fa-regular fa-folder-closed"></i><span id="list-items">Transaction</span></a>
        </li>
        <li class="submenu" id="submenu">
            <a href="javascript:void(0);"><i class="fas fa-regular fa-message"></i>
            <span id="list-items">Messages</span>
            <!-- <i class="fa-solid fa-caret-down drop" style="transform: rotate(-90deg);"></i> -->
        
        </a>

            <ul class="dropdown-items" id="dropdown-items">
                <li><a href="">Admin Messages</a></li>
                <li><a href="">Client Messages</a></li>
                <li><a href="">Staff Messages</a></li>
            </ul>
        </li>
        <li class="submenu">
            <a href="javascript:void(0);"><i class="fas fa-regular fa-folder-closed"></i><span id="list-items">Document</span></a>
            <ul class="dropdown-items" id="dropdown-items">
                <li><a href="">Admin Messages</a></li>
                <li><a href="">Client Messages</a></li>
                <li><a href="">Staff Messages</a></li>
            </ul>
        </li>
        <li>
            <a href=""><i class="fas fa-regular fa-folder-closed"></i><span id="list-items">System User</span></a>
        </li>
        <li class="">
            <a href=""><i class="fas fa-solid fa-wallet"></i><span id="list-items">Wallet</span></a>
        </li>
        <li>
            <a href=""><i class="fas fa-light fa-file-lines"></i><span id="list-items">Reports</></a>
        </li>
        <li>
            <a href=""><i class="fas fa-light fa-file-lines"></i><span id="list-items">Email</span></a>
        </li>
        <li>
            <a href=""><i class="fas fa-light fa-file-lines"></i><span id="list-items">SMS</span></a>
        </li>
        <li>
            <a href=""><i class="fas fa-light fa-file-lines"></i><span id="list-items">Live sms</span></a>
        </li>
         </ul>
        
         <div id="bottom">
          <li class="submenu">
          <a href="javascript:void(0);"><i class="fas fa-light fa-gear"></i><span id="list-items">Settings </span></a>
          <ul class="dropdown-items" id="dropdown-items">
                <li><a href="">Admin Messages</a></li>
                <li><a href="">Client Messages</a></li>
                <li><a href="">Staff Messages</a></li>
            </ul>
          </li>
          <li>
            <a href=""><i class="fas fa-light fa-life-ring"></i><span id="list-items">Support</span></a>
            </li>
        </div>
        
   
   
</nav>
</div>  
