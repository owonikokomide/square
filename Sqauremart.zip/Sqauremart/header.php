<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="css/all.css">
    <!-- <link rel="stylesheet" href="style.css"> -->
    <link rel="stylesheet" href="header.css">
    <link rel="stylesheet" href="admin.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.17.0/xlsx.full.min.js"></script>

</head>
<body>
 
    <header>
        <div class="admin-header left-sec">
            <i class="fa-solid fa-bars" id="opennav" onclick="togglenav()"></i>
            <i class="fa-solid fa-bars" id="expand" onclick="expand()"></i>
            <i class="fa-solid fa-times" id="contrast" onclick="contrast()"></i>
        </div>
        <div class="admin-header mid-sec">
           <img src="logo.png" alt=""/>
        <!-- <input type="search" name="" id=""> -->
        </div>
        <div class="admin-header bell">
            <i class="fa-solid fa-bell"></i>
            <span>2</span>

        </div>
        <div class="admin-header right-sec">

           <i class="fa-solid fa-right-from-bracket"></i><span> Logout </span>
        </div>
    </header>
