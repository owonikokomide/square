<?php include('header.php') ?>
<div class="admin-wrapper-page">
        <div class="admin-wrapper-col-4" id="sidenav">
<div class="admin-main">
    <div class="admin-sidebar">
        <?php include('sidebar.php') ?>
    </div>
</div>
</div>
<div class="admin-data-widget-wrapper">
  <div class="data-widget-grid-box">
    <div class="dash-widget-row">
      <div class="dash-widget bg-pink">
        <h1>Withdrawals</h1>
        <p>9750</p>
      </div>
      <div class="dash-widget bg-light-yellow">
      <h1>Deposits</h1>
        <p>9750</p>
      </div>
      <div class="dash-widget bg-primary">
      <h1>Total Fees</h1>
        <p>9750</p>
      </div>
      <div class="dash-widget bg-light-red">
      <h1>Total Transaction</h1>
        <p>9750</p>
      </div>
      <div class="dash-widget bg-blue">
      <h1>Website Visits</h1>
        <p>9750</p>
      </div>
      <div class="dash-widget bg-orange">
      <h1>Total Customers</h1>
        <p>9750</p>
      </div>
      <div class="dash-widget bg-grey">
      <h1>Assets</h1>
        <p>9750</p>
      </div>
      <div class="dash-widget bg-teal">
      <h1>Total Products</h1>
        <p>9750</p>
      </div>
    </div>
  </div>

<div class="chart-div">
<div class="chart-row">
  <div></div>
  <div class="chart-col-l6">
        <div id="firsthistogram" class="chart-set"></div>


  </div>
  <div class="chart-col-l6">
  <div id="secondhistogram" class="chart-set"></div>

</div>
<div></div>
</div>
</div>






  <div class="table-grid-row">
    
  <div class="admin-withdraw-col-6">
                <div class="head"> 
                    
                        <h4>withdrawal</h4>
                    <div class="table-responsive" id="printable-area">
                        <table id="tableToConvert" class="admin-out">
                            <tr>
                              
                                <th>User id</th>
                                <th id="payment">Payment Method</th>
                                <th>Amount</th>
                                <th>Status</th>
                                
                            </tr>
                       
                          <tr>
                               
                                <td>$baby</td>
                                <td>Bank</td>
                                <td>200</td>
                             
                                <td><button class="admin-error">cancel</button></td>
                              </tr>
                              <tr>
                                <td>$baby</td>
                                <td>Bank</td>
                                <td>200</td>
                             
                                <td><button class="admin-success">success</button></td>

                                </tr>
                                <tr>

                                <td>$baby</td>
                                <td>Bank</td>
                                <td>200</td>
                             
                                <td><button class="admin-det">pending</button></td>
                               
                            </tr>
                        </table>
              
                        </div>
    </div>

               
            </div>


            <!-- deposit table -->
            <div class="admin-deposit-col-6">
                <div class="head"> 
                    
                        <h4>Deposit</h4>
                    <div class="table-responsive" id="printable-area">
                        <table id="tableToConvert" class="admin-out">
                            <tr>
                              
                                <th>User id</th>
                                <th id="payment">Payment Method</th>
                                <th>Amount</th>
                                <th>Status</th>
                                
                            </tr>
                       
                          <tr>
                               
                                <td>$baby</td>
                                <td>Bank</td>
                                <td>200</td>
                             
                                <td><button class="admin-error">cancel</button></td>
                              </tr>
                              <tr>
                                <td>$baby</td>
                                <td>Bank</td>
                                <td>200</td>
                             
                                <td><button class="admin-success">success</button></td>

                                </tr>
                                <tr>

                                <td>$baby</td>
                                <td>Bank</td>
                                <td>200</td>
                             
                                <td><button class="admin-det">pending</button></td>
                               
                            </tr>
                        </table>
              
                        </div>
    </div>

               
            </div>

  </div>

  <div class="growth-grid-row">
    <div class="growth-dash">
      <div class="round-chart">
<canvas id="chartPie" class="h-300"></canvas>
      </div>
      <div class="customer-growth">
        <div class="head">Customer's Growth</div>
        <div class="growth-body">
          <div class="country-lists">
            <label for="">Nigeria</label>
            <div class="progress-container">
              <div id="progressbar" data-width="95"></div>
            </div>
               <!-- <progress> 50%</progress>  -->
          </div>
          <div class="country-lists">
          <label for="">Kenya</label>
          <div class="progress-container">
              <div id="progressbar" data-width="8"></div>
            </div>
               <!-- <progress> 50%</progress>  -->
          </div>
          <div class="country-lists">
          <label for="">Ghana</label>
          <div class="progress-container">
              <div id="progressbar" data-width="25"></div>
            </div>
               <!-- <progress> 50%</progress>  -->
          </div>
          <div class="country-lists">
          <label for="">United states</label>
          <div class="progress-container">
              <div id="progressbar" data-width="40"></div>
            </div>  <!-- <progress> 50%</progress>  -->
          </div>
          <div class="country-lists">
          <label for="">United kingdom</label>
          <div class="progress-container">
              <div id="progressbar" data-width="50"></div>
            </div>
               <!-- <progress> 50%</progress>  -->
          </div>
        </div>
      </div>
    </div>
  </div>
  
</div>
</div>


<script src="js/jquery-3.6.0.min.js"></script>
<script src="js/apexcharts.min.js"></script>
<script src="js/progress.js"></script>
<script src="js/apex.js"></script>
<script src="js/chart.min.js"></script>
<script src="js/chart.js"></script>

<?php include('footer.php');?>