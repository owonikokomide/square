<footer>
    Copyright &copy; <?php 
        $t = date("Y");
        echo $t;
        ?> Squareswap Inc. All rights reserved.
</footer>

<script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>

<script>



      function searchTable() {
  const input = document.getElementById("searchInput").value.toLowerCase(); // Get the search input and convert to lowercase
  const table = document.getElementById("tableToConvert"); // Get the table element
  const rows = table.querySelectorAll("tr:not(:first-child)"); // Select all rows except the header row

  rows.forEach(row => {
    const columns = row.querySelectorAll("td");
    let found = false;

    columns.forEach(column => {
      if (column.textContent.toLowerCase().includes(input)) {
        found = true;
      }
    });

    if (found) {
      row.style.display = ""; // Show the row if a match is found
    } else {
      row.style.display = "none"; // Hide the row if no match is found
    }
  });
}


        const table = document.getElementById("tableToConvert");
        const rows = table.getElementsByTagName("tr");
        const prevBtn = document.getElementById("prevBtn");
        const nextBtn = document.getElementById("nextBtn");
        const rowsPerPageSelect = document.getElementById("rowsPerPage");

        let currentPage = 0;
        let rowsPerPage = parseInt(rowsPerPageSelect.value); // the value in the select

        function showPage(pageNumber) {
            // pagenumber = currentpage = 0
            for (let i = 1; i < rows.length; i++) {
                if (i > pageNumber * rowsPerPage && i <= (pageNumber + 1) * rowsPerPage) {
                    // if i greater than 0 and less then the current page 
                    rows[i].style.display = "";
                } else {
                    rows[i].style.display = "none";
                }
            }
        }

        function updatePage() {
            showPage(currentPage);
        }

        prevBtn.addEventListener("click", () => {
            if (currentPage > 0) {
                currentPage--;
                updatePage();
            }
        });

        nextBtn.addEventListener("click", () => {
            if (currentPage < Math.ceil(rows.length / rowsPerPage) - 1) {
                currentPage++;
                updatePage();
            }
        });

        rowsPerPageSelect.addEventListener("change", () => {
            rowsPerPage = parseInt(rowsPerPageSelect.value);
            currentPage = 0;
            updatePage();
        });

        updatePage();

        function printDiv(divId) {
  var printContents = document.getElementById(divId).innerHTML;
  var originalContents = document.body.innerHTML;

  document.body.innerHTML = printContents;
  window.print();
  document.body.innerHTML = originalContents;
}


</script>
<script>
//dropdownitems

const dropnavs = document.querySelectorAll('.submenu');
const dropdownitems = document.querySelectorAll('#dropdown-items');
// console.log(dropdownitems.length); 
for(k = 0; k < dropdownitems.length; k++){
    dropnavs[k].addEventListener("click", ()=> {
      
    dropdownitems.style.display ="block";
        
    });
}





    function openNav(){
       
        const listall = document.querySelectorAll('#list-items');
        const navs = document.querySelector('.collapsible');
        const leftsec = document.querySelector('.left-sec');
        const adminwrapperpage = document.querySelector('.admin-wrapper-page');
        const admindatawidget = document.querySelector('.admin-data-widget-wrapper');
        const footer = document.querySelector('footer');
            navs.addEventListener("mouseover", function(){
                navs.style.transition = "width 0.6s";
               
                navs.style.width="16%";
            leftsec.style.marginLeft = "17em";
            adminwrapperpage.style.gap ="12em";
            admindatawidget.style.overflow = "hidden";

            // header.style.width="80%";
            // header.style.left="18%";
            footer.style.left="13em";
            for(j =0; j < listall.length; j++ ){
            listall[j].style.display="block";
            }
            });
           navs.addEventListener("mouseout", function(){
                navs.style.width="4%";
            leftsec.style.marginLeft = "3em";
            adminwrapperpage.style.gap ="0em";


            // header.style.width="92%";
            // header.style.left="6%";
            footer.style.left="5em";
            for(j =0; j < listall.length; j++ ){
            listall[j].style.display="none";
            
              
            }
            });
    

    }
    function togglenav(){
      const sidenavstyle = document.getElementById('sidenav');
    
        sidenavstyle.style.display="block";
        document.querySelector('.collapsible').style.width="80%";
    
    }
    function closenav(){
      const sidenavstyle = document.getElementById('sidenav');
      sidenavstyle.style.transition ="width 1s";
        sidenavstyle.style.display="none";
       
    }
    function expand(){
        const footer = document.querySelector('footer');
        const navs = document.querySelector('.collapsible');
        const leftsec = document.querySelector('.left-sec');
        const list = document.querySelectorAll('#list-items');
        const listall = document.querySelectorAll('#list-items');
        const adminwrapperpage = document.querySelector('.admin-wrapper-page');
        const admindatawidget = document.querySelector('.admin-data-widget-wrapper');
        // if(navs.style.width=="15%"){
    
            navs.style.width="4%";
            leftsec.style.marginLeft = "4em";
            adminwrapperpage.style.gap ="0em";
           
            footer.style.left="5em";
            document.getElementById('expand').style.display="none";
            document.getElementById('contrast').style.display="block";

            for(i =0; i < list.length; i++ ){
            list[i].style.display="none";

            }
            navs.addEventListener("mouseover", function(){
                navs.style.transition = "width 0.6s";
                navs.style.width="16%";


  
            leftsec.style.marginLeft = "17em";
            adminwrapperpage.style.gap ="12em";
            admindatawidget.style.overflow = "hidden";
            // admindatawidget.style.marginLeft = "5em";
            // admindatawidget.style.marginRight = "3em";


            // header.style.width="80%";
            // header.style.left="18%";
            footer.style.left="13em";
            for(j =0; j < listall.length; j++ ){
            listall[j].style.display="block";
            }
            });
           navs.addEventListener("mouseout", function(){
                navs.style.width="4%";
            leftsec.style.marginLeft = "4em";
            adminwrapperpage.style.gap ="0em";


            // header.style.width="92%";
            // header.style.left="6%";
            footer.style.left="5em";
            for(j =0; j < listall.length; j++ ){
            listall[j].style.display="none";
              
            }
            });

        }
        function  contrast(){
        const listall = document.querySelectorAll('#list-items');
        const adminwrapperpage = document.querySelector('.admin-wrapper-page');

            const footer = document.querySelector('footer');
        const navs = document.querySelector('.collapsible');
        const leftsec = document.querySelector('.left-sec');
        const list = document.querySelectorAll('#list-items');
        document.getElementById('expand').style.display="block";
            document.getElementById('contrast').style.display="none";
            navs.style.transition = "width 0.6s";
           
            navs.style.width="16%";
            leftsec.style.marginLeft = "17em";
            adminwrapperpage.style.gap="12em";

            // header.style.width="80%";
            // header.style.left="18%";
            footer.style.left="13em";
            // openNav(1);
            
            for(i =0; i < list.length; i++ ){
            list[i].style.display="block";

            }
            navs.addEventListener("mouseover", function(){
                navs.style.width="16%";
           
                leftsec.style.marginLeft = "17em";
            adminwrapperpage.style.gap="12em";


            // header.style.width="80%";
            // header.style.left="18%";
            footer.style.left="13em";
            for(j =0; j < listall.length; j++ ){
            listall[j].style.display="block";
            }
            });
            navs.addEventListener("mouseout", function(){
                navs.style.width="16%";
            leftsec.style.marginLeft = "17em";
            adminwrapperpage.style.gap="12em";

            // header.style.width="80%";
            // header.style.left="18%";
            footer.style.left="13em";
            for(j =0; j < listall.length; j++ ){
            listall[j].style.display="block";
            }
            });

        }
    
</script>


</body>
</html>