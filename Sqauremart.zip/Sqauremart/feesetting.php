<?php include('header.php') ?>
<div class="admin-wrapper-page">
        <div class="admin-wrapper-col-4" id="sidenav">
<div class="admin-main">
    <div class="admin-sidebar">
        <?php include('sidebar.php') ?>
    </div>
</div>
</div>
<div class="admin-wrapper-col-8">
        <div class="admin-topic">Fees setting</div>
        <div class="admin-form-group-add">
            <div class="admin-head-type">
                <h4>Transactions Setup</h4>
                <h4>Fees Setting</h4>
                </div>
                <div class="form-container">
                    <div class="form-row">
                        <div class="admin-form-col-6">
                            <form action="" method="post">
                                <div class="form-group">
                                    <div class="form-input">
                                        <label for="">limit</label>
                                        <input type="text" name="" id="">
                                    </div>
                                    <div class="form-input">
                                        <label for="">Transaction Type</label>
                                        <select name="" id="">
                                            <option value=""></option>
                                            <option value="">USDT</option>
                                            <option value="">USD</option>
                                        </select>

                                    </div>
                                    <div class="form-input">
                                        <label for="">Account Type</label>
                                        <select name="" id="">
                                            <option value=""></option>
                                            <option value="">USDT</option>
                                            <option value="">USD</option>
                                        </select>

                                    </div>
                                    <button type="submit" class="submit">
                                        save
                                        
                                        </button>
                                </div>
                            </form>

                        </div>
                        <div class="admin-form-col-6">
                            <h4>Fees setting</h4>
                        <form action="" method="post">
                                <div class="form-group">
                                    
                                    <div class="form-input">
                                        <label for="">Transaction Type</label>
                                        <select name="" id="">
                                            <option value="" selected disabled>select option</option>
                                            <option value="">USDT</option>
                                            <option value="">USD</option>
                                        </select>

                                    </div>
                                    <div class="form-input">
                                        <label for="">Fees%</label>
                                        <input type="text" name="" id="">

                                    </div>
                                    <button type="submit" class="submit">
                                        save
                                        
                                        </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
               
               </div>
               
       


         
        </div>
        </div>
   


<?php include('footer.php') ?>