// const progressbar = document.querySelectorAll('#progressbar');
// const realwidth = progressbar.dataset.width;
window.addEventListener('load', ()=>{
  const progressbars = document.querySelectorAll('#progressbar');
  progressbars.forEach(progressbar =>{
    const targetWidth = progressbar.getAttribute('data-width');
    let currentWidth = 0;
    const interval = setInterval( () => {

      if(currentWidth >= targetWidth){
        clearInterval(interval);
      }else {
        currentWidth++;
        progressbar.style.width = currentWidth + '%';
      }


    }, 30);

  });

});
// console.log(progressbar.length);
// for(i = 0; i < progressbar.length; i++){
//   const realwidth = progressbar[i].dataset.width;
//   progressbar[i].style.width = realwidth + '%';
//   console.log(width);
  
// }