 var datapie={labels:['USDT','Delivery','Giftcard','Market'],datasets:[{data:[35,8,15,24],backgroundColor:['lightgreen','lightblue','pink','purple']}]};var optionpie={maintainAspectRatio:false,responsive:true,legend:{display:false,},animation:{animateScale:true,animateRotate:true}};var ctx6=document.getElementById('chartPie');var myPieChart6=new Chart(ctx6,{type:'doughnut',data:datapie,options:optionpie});



 // });
 